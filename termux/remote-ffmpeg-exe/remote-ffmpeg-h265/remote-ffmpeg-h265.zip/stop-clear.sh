#!/data/data/com.termux/files/usr/bin/bash

# rsync rh265

pkill rh265
pkill rh265
pkill rh265

pkill rsync
pkill rsync
pkill rsync
