#write to ~/../usr/etc/bash.bashrc 
# 好像不行，不过可以写到 ~/.bashrc, 但会导致每次登录都要执行，浪费系统资源。应考虑用termux-boot

# pkg install -y openssh # golang和make都不用装，因为frp已经编译好了

termux-wake-lock

sshd

# 远程登录会因为kill掉frpc而掉线，故此处将弃用
# pids=`ps aux|awk '/frpc/{print $1}'`
# for pid in $pids
# do
#     kill -9 $pid
# done
pNum=`ps -ef|grep -w frpc|grep -v grep|wc -l`
if [ $pNum -eq 0 ]; then
    nohup ~/mydir/bin/frp/frpc -c ~/mydir/bin/frp/conf/frpc.ini &
fi

# 假定操控端本地也已启动frpc实例，监听端口2088，通过远程服务器的frps，间接连接到被控手机Termux的SSH服务(8022端口)
nohup curl "https://tg.imsb.pro/ppmtb/cnmb/462394947?msg=laoda-termux-startup-username-is-"`whoami`".%20Command:%20ssh%20-l"`whoami`"%20-p2088%20localhost" &
